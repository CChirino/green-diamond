## Martfury Vue 1.3.0

#### Verion 1.3.0
* New: group pages by layouts
* Fixed: Homepage-default's banner not equal height
* Fixed: Product wide not working on shop page.
* Refactor code 
