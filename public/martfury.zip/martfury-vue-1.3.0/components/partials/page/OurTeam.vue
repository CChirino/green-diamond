<template lang="html">
    <div class="ps-our-team">
        <div class="container">
            <div class="ps-section__header">
                <h3>Meet Our Leaders</h3>
            </div>
            <div class="ps-section__content">
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/1.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/2.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/3.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/4.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/5.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/6.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure>
                    <div class="ps-block--ourteam">
                        <img src="/img/users/our-team/7.jpg" alt="martfury" />
                        <div class="ps-block__content">
                            <h4>Robert Downey Jr</h4>
                            <p>CEO Fouder</p>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </figure>
                <figure data-mh="our-team">
                    <div class="ps-block--ourteam blank">
                        <a href="#">
                            Become <br />
                            member in <br />
                            team
                        </a>
                    </div>
                </figure>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'OurTeam'
};
</script>

<style lang="scss" scoped></style>
