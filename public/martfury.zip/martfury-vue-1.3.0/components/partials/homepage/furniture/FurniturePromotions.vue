<template lang="html">
    <div class="ps-home-promotions">
        <div class="container">
            <div class="ps-section__header">
                <h3>
                    WELCOME TO <span>MARTFURY</span> – CUSTOM FURNITURE
                    <span>SHOPPING STORE ONLINE</span>
                </h3>
                <p>Designer furniture. Locally designed. Globally Crafted.</p>
            </div>
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 ">
                    <a class="ps-collection" href="#">
                        <img
                            src="~/static/img/promotions/home-8/1.jpg"
                            alt="martfury"
                        />
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
                    <a class="ps-collection" href="#">
                        <img
                            src="~/static/img/promotions/home-8/2.jpg"
                            alt="martfury"
                        />
                    </a>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'FurniturePromotions'
};
</script>

<style lang="scss" scoped></style>
