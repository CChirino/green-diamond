<template lang="html">
    <div class="ps-home-promotions">
        <nuxt-link to="/">
            <img
                src="~/static/img/promotions/home-5/simple.jpg"
                alt="martfury"
            />
        </nuxt-link>
    </div>
</template>

<script>
export default {
    name: 'MarketPlace3Promotions'
};
</script>

<style lang="scss" scoped></style>
