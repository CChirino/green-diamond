<template lang="html">
    <div class="ps-promotions">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
                    <a class="ps-collection" href="#">
                        <img
                            src="~/static/img/promotions/home-3-1.jpg"
                            alt=""
                        />
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
                    <a class="ps-collection" href="#">
                        <img
                            src="~/static/img/promotions/home-3-2.jpg"
                            alt=""
                        />
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
                    <a class="ps-collection" href="#">
                        <img
                            src="~/static/img/promotions/home-3-3.jpg"
                            alt=""
                        />
                    </a>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'MarketPlacePromotion'
};
</script>

<style lang="scss" scoped></style>
