<template lang="html">
    <div class="ps-promotions">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <nuxt-link to="/shop" class="ps-collection">
                        <img
                            src="~/static/img/promotions/home-6/1.jpg"
                            alt="martfury"
                        />
                    </nuxt-link>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <nuxt-link to="/shop" class="ps-collection">
                        <img
                            src="~/static/img/promotions/home-6/2.jpg"
                            alt="martfury"
                        />
                    </nuxt-link>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'MartketPlace4Promotions'
};
</script>

<style lang="scss" scoped></style>
