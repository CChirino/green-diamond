<template lang="pug">
    figure.ps-block--testimonial
        .ps-block__content
            p Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
        .ps-block__footer
            small Sandar Couter - CEO Winnny.ltd
</template>
