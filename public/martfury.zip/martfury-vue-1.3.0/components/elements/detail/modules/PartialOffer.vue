<template lang="html">
    <p>Sorry no more offers available</p>
</template>

<script>
export default {
    name: 'PartialOffer'
};
</script>

<style lang="scss" scoped></style>
